Sample: histogram
Minimum spec: SM 2.0

This sample demonstrates efficient implementation of 64-bin and 256-bin histogram.

Key concepts:
Image Processing
Data Parallel Algorithms
