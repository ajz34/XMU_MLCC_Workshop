Sample: stereoDisparity
Minimum spec: SM 2.0

A CUDA program that demonstrates how to compute a stereo disparity map using SIMD SAD (Sum of Absolute Difference) intrinsics.  Requires Compute Capability 2.0 or higher.

Key concepts:
Image Processing
Video Intrinsics
