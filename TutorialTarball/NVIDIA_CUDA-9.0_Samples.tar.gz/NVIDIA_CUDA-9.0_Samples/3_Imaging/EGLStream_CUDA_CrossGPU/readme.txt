Sample: EGLStream_CUDA_CrossGPU
Minimum spec: SM 2.0

Demonstrates CUDA and EGL Streams interop, where consumer's EGL Stream is on one GPU and producer's on other and both consumer-producer are different processes.

Key concepts:
EGLStreams Interop
