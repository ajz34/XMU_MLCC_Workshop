Sample: convolutionSeparable
Minimum spec: SM 2.0

This sample implements a separable convolution filter of a 2D signal with a gaussian kernel.

Key concepts:
Image Processing
Data Parallel Algorithms
