Sample: simpleLayeredTexture
Minimum spec: SM 2.0

Simple example that demonstrates how to use a new CUDA 4.0 feature to support layered Textures in CUDA C.

Key concepts:
Texture
Volume Processing
