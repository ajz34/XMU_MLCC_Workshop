Sample: simpleZeroCopy
Minimum spec: SM 2.0

This sample illustrates how to use Zero MemCopy, kernels can read and write directly to pinned system memory.

Key concepts:
Performance Strategies
Pinned System Paged Memory
Vector Addition
