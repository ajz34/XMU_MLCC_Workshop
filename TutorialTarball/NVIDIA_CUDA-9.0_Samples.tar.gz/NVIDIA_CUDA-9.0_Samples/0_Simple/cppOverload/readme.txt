Sample: cppOverload
Minimum spec: SM 2.0

This sample demonstrates how to use C++ function overloading on the GPU.

Key concepts:
C++ Function Overloading
CUDA Streams and Events
