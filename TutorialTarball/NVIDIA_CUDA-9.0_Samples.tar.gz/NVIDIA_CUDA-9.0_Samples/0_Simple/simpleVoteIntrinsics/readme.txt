Sample: simpleVoteIntrinsics
Minimum spec: SM 2.0

Simple program which demonstrates how to use the Vote (any, all) intrinsic instruction in a CUDA kernel.  Requires Compute Capability 2.0 or higher.

Key concepts:
Vote Intrinsics
