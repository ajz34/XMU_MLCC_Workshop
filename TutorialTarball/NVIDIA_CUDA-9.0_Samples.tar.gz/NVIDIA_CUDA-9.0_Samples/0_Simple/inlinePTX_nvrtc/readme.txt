Sample: inlinePTX_nvrtc
Minimum spec: SM 2.0

A simple test application that demonstrates a new CUDA 4.0 ability to embed PTX in a CUDA kernel.

Key concepts:
Performance Strategies
PTX Assembly
CUDA Driver API
Runtime Compilation
