Sample: simpleAtomicIntrinsics_nvrtc
Minimum spec: SM 2.0

A simple demonstration of global memory atomic instructions.This sample makes use of NVRTC for Runtime Compilation.

Key concepts:
Atomic Intrinsics
Runtime Compilation
