Sample: simplePitchLinearTexture
Minimum spec: SM 2.0

Use of Pitch Linear Textures

Key concepts:
Texture
Image Processing
