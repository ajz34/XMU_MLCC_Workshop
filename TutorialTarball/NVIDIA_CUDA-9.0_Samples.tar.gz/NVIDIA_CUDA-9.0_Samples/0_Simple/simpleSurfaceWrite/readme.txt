Sample: simpleSurfaceWrite
Minimum spec: SM 2.0

Simple example that demonstrates the use of 2D surface references (Write-to-Texture)

Key concepts:
Texture
Surface Writes
Image Processing
