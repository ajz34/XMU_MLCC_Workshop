Sample: batchCUBLAS
Minimum spec: SM 2.0

A CUDA Sample that demonstrates how using batched CUBLAS API calls to improve overall performance.

Key concepts:
Linear Algebra
CUBLAS Library
