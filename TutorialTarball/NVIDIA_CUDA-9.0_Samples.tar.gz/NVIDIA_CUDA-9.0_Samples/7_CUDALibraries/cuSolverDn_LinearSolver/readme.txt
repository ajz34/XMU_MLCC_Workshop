Sample: cuSolverDn_LinearSolver
Minimum spec: SM 2.0

A CUDA Sample that demonstrates cuSolverDN's LU, QR and Cholesky factorization.

Key concepts:
Linear Algebra
CUSOLVER Library
