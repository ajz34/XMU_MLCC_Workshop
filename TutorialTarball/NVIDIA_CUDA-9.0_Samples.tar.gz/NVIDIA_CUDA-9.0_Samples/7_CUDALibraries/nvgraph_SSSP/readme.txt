Sample: nvgraph_SSSP
Minimum spec: SM 3.0

A CUDA Sample that demonstrates Single Source Shortest Path(SSSP) computation using NVGRAPH Library.

Key concepts:
Graph Analytics
NVGRAPH Library
