Sample: randomFog
Minimum spec: SM 2.0

This sample illustrates pseudo- and quasi- random numbers produced by CURAND.

Key concepts:
3D Graphics
CURAND Library
