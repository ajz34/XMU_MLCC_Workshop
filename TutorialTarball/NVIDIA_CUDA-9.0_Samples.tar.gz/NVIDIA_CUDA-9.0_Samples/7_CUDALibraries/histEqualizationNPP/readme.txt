Sample: histEqualizationNPP
Minimum spec: SM 2.0

This CUDA Sample demonstrates how to use NPP for histogram equalization for image data.

Key concepts:
Image Processing
Performance Strategies
NPP Library
