Sample: simpleDevLibCUBLAS
Minimum spec: SM 3.5

This sample implements a simple CUBLAS function calls that call GPU device API library running CUBLAS functions.  This sample requires a SM 3.5 capable device.

Key concepts:
CUDA Dynamic Parallelism
Linear Algebra
