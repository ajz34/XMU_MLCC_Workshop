Sample: simpleCUBLASXT
Minimum spec: SM 2.0

Example of using CUBLAS-XT library.

Key concepts:
CUBLAS-XT Library
