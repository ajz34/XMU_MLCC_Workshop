Sample: cuSolverSp_LowlevelQR
Minimum spec: SM 2.0

A CUDA Sample that demonstrates QR factorization using cuSolverSP's low level APIs.

Key concepts:
Linear Algebra
CUSOLVER Library
