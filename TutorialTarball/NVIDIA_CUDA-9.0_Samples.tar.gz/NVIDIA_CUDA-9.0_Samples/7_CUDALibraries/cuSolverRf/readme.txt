Sample: cuSolverRf
Minimum spec: SM 2.0

A CUDA Sample that demonstrates cuSolver's refactorization library - CUSOLVERRF.

Key concepts:
Linear Algebra
CUSOLVER Library
