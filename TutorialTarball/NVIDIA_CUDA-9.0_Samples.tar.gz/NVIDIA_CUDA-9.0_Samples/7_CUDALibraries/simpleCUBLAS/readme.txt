Sample: simpleCUBLAS
Minimum spec: SM 2.0

Example of using CUBLAS using the new CUBLAS API interface available in CUDA 4.0.

Key concepts:
Image Processing
CUBLAS Library
