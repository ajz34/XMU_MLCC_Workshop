#!/bin/bash

tar -xjf cp2k-4.1.tar.bz2
cd cp2k-4.1/makefiles
make libcp2k ARCH=Linux-x86-64-intel-host VERSION=popt
cd ../..
cp cp2k-4.1/lib/Linux-x86-64-intel-host/popt/libcp2k.a cp2k-4.1/obj/Linux-x86-64-intel-host/popt/f77_interface.mod cp2k-4.1/obj/Linux-x86-64-intel-host/popt/input_cp2k.mod cp2k-4.1/obj/Linux-x86-64-intel-host/popt/input_section_types.mod .
