#!/bin/bash

tar -xzf siesta-4.1-b3.tar.gz
cd siesta-4.1-b3/Src
sed -i 's/periodic_table/peri_table_sie/g' *.f *.F
cd ../Obj
sh ../Src/obj_setup.sh
cp ../../arch.make .
make version
make lib 
cp libSiestaXC.a libfdf.a fsiesta.mod libwxml.a libSiestaForces.a ../..
cd ../..
