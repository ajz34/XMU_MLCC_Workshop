#!/bin/bash

tar -xf lammps-*.tar.gz
cd lammps-*/src
make mode=lib mpi 
cp liblammps_mpi.a ../..
cd ../examples/COUPLE/fortran2/
sed -i 's/FC = mpif90/FC = mpiifort/g' makefile
make 
cp liblammps_fortran.a lammps.mod ../../../..
cd ../../../..
