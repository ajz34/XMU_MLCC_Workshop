#! /bin/bash

rm -rf vasp.5.3 vasp.5.lib
tar -xzf vasp.5.3.5.tar.gz
tar -xzf vasp.5.lib.tar.gz
cd vasp.5.lib
cp ../makefile.lib makefile
make 
cd ../vasp.5.3
  for i in `ls *.F`; do sed -i 's/USE radial/USE radial_vasp/g' $i; done
  sed -i 's/MODULE mp2/MODULE mp2_vasp/g' ump2.F
  sed -i 's/MODULE bse/MODULE bse_vasp/g' bse.F
  sed -i 's/USE mp2/USE mp2_vasp/g' chi.F
  sed -i 's/USE bse/USE bse_vasp/g' chi.F
  sed -i 's/mp2_vaspkpar/mp2kpar/g' chi.F
  tar -xzf ../patch.vasp.tar.gz
  for i in `cat patch.vasp/patch.list`; do patch $i patch.vasp/$i.patch ;done
  cp ../makefile.vasp ./makefile
  if [ "$MKLROOT" != "" ]; then sed -i 's/\#for_lasp //g' makefile ; fi
    make
  rm -rf patch.vasp
  cp libvasp.a ..
  make clean
  sed -i 's/-DNGZhalf/-DNGZhalf -DwNGZhalf/g' makefile
    make
  cp libvasp.a ../libvasp-gamma.a
  \cp ../makefile.lib makefile
cd ..
