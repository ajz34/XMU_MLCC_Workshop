rm -rf dftd3
mkdir dftd3
cd dftd3
tar -xzf ../dftd3.tgz
cp ../Makefile.dftd3  Makefile
patch dftd3.f ../dftd3.patch
make
cp d3-lib.a ..
