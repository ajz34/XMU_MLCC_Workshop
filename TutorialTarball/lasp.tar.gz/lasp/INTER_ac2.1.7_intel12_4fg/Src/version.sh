a=`ifort --version|head -1|sed 's/\./ /g'|awk '{print $3}'`
sed "s/iver/iver=$a/" version.pre >version.f90
