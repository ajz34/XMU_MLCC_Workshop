#!/bin/bash

#---Provide any necessary defination here ---------------------------
exec='g09'
inputfile='gaussian.inp'
outputfile='gaussian.out'
charge=0                  # Set charge here
multi=1                   # Set multiplicity here
#mpirun=''
#machinefile=''
#nprocs=''

#---Prepare the "parameter" input file here -------------------------
cat $inputfile.pre >$inputfile 
a=`grep '%chk' $inputfile.pre|sed 's/=/ /g'|awk '{print $2}'`
if [ "$1" == "T" ];then \rm -f $a;fi
if [ -f "$a" ]; then echo "Guess=Read">>$inputfile;fi
echo "" >>$inputfile
echo "lasp external" >>$inputfile
echo "" >>$inputfile
echo $charge "  "  $multi >>$inputfile

#---Prepare the "coordinate" input file here ------------------------
sed 1,3d external.coord|awk '{print $1,$2,$3,$4}' >>$inputfile
echo "" >>$inputfile
if [ -f "$inputfile.after" ]; then 
  cat $inputfile.after >>$inputfile
fi
echo "" >>$inputfile
echo "" >>$inputfile
#---Run the executable file here ------------------------------------
\rm -f $outputfile.old;mv $outputfile $outputfile.old
$exec <$inputfile >$outputfile

#---Extract energy here ---------------------------------------------
grep "Total Energy" Test.FChk|awk '{printf ("%.15f\n",$4*27.211383)}' >external.ene

#---Extract force here ----------------------------------------------
b=`grep -m1 -n 'Cartesian Gradient' Test.FChk|sed 's/:/ /'|awk '{print $1}'`
c=`grep -m1 -n 'Cartesian Force Constants' Test.FChk|sed 's/:/ /'|awk '{print $1}'`
let "d=$c-$b-1"
grep -m1 -A$d 'Cartesian Gradient' Test.FChk|sed 1d|awk -v m=-51.422057 '{printf ("%.15f %.15f %.15f %.15f %.15f\n",$1*m,$2*m,$3*m,$4*m,$5*m)}' >>external.ene


#---Extract stress here ---------------------------------------------
#---Cleanance -------------------------------------------------------
