#!/bin/bash

#---Provide any necessary defination here ---------------------------
exec='/home2/shang/program/package_and_old/siesta-4.1-b3/Obj/siesta'
inputfile='siesta.fdf'
outputfile='siesta.out'
machinefile=./machinefile
nprocs=`cat ./nprocs`

#---Prepare the "parameter" input file here -------------------------
if [ ! -f $inputfile.lasp.external ]; then
  cp $inputfile $inputfile.lasp.external
  sed -i '/Diag.DivideAndConquer/d'     $inputfile.lasp.external
  sed -i '/MD.VariableCell/d'           $inputfile.lasp.external
  sed -i '/DM.UseSaveDM/d'              $inputfile.lasp.external
  sed -i '/MD.UseSaveXV/d'              $inputfile.lasp.external
  sed -i '/Write.DM/d'                  $inputfile.lasp.external
  sed -i '/MD.TypeOfRun/d'              $inputfile.lasp.external
  sed -i '/MD.NumCGsteps/d'             $inputfile.lasp.external
  echo "Diag.DivideAndConquer False " >>$inputfile.lasp.external
  echo "MD.VariableCell True " >>       $inputfile.lasp.external
  echo "DM.UseSaveDM    True " >>       $inputfile.lasp.external
  echo "MD.UseSaveXV    True " >>       $inputfile.lasp.external
  echo "Write.DM        True " >>       $inputfile.lasp.external
  echo "MD.TypeOfRun    CG   " >>       $inputfile.lasp.external
  echo "MD.NumCGsteps   0 " >>          $inputfile.lasp.external
fi
\cp -f $inputfile.lasp.external $inputfile

#---Prepare the "coordinate" input file here ------------------------
z=(`grep -n AtomicCoordinatesAndAtomicSpecies siesta.fdf|sed 's/:/ /g'|awk '{print $1}'`)
sed -i ${z[0]},${z[1]}d $inputfile
a=`grep 'SystemLabel' $inputfile|awk '{print $NF}'`
\rm -f $a.XV
head -3 external.coord|awk -v m=1.8897259886 '{printf ("%.15f %.15f %.15f %.3f %.3f %.3f\n",$1*m,$2*m,$3*m,0,0,0)}' >$a.XV
n=`grep NumberOfAtoms $inputfile|awk '{print $NF}'`
echo "  "$n >>$a.XV
c=`grep NumberOfSpecies $inputfile|awk '{print $NF}'`
d=(`grep -m1 -A$c ChemicalSpeciesLabel $inputfile|sed 1d|awk '{print $3}'`)
e=(`grep -m1 -A$c ChemicalSpeciesLabel $inputfile|sed 1d|awk '{print $2}'`)
echo '%block AtomicCoordinatesAndAtomicSpecies' >>$inputfile
\rm -f lasp.coord.tmp
j=0
for i in ${d[*]}
do
  let "k=$j+1"
  grep "$i " external.coord >>lasp.coord.tmp
  grep "$i " lasp.coord.tmp|awk -v m="$k" -v n="${e[$j]}" -v o=1.8897259886 '{printf ("%u %u %.15f %.15f %.15f %.3f %.3f %.3f\n",m,n,$2*o,$3*o,$4*o,0,0,0)}'>>$a.XV
  grep "$i " external.coord|awk -v m="$k" '{print $2,$3,$4,m}' >>$inputfile
  j=$k
done
echo '%endblock AtomicCoordinatesAndAtomicSpecies' >>$inputfile
#---Run the executable file here ------------------------------------
mpirun --rsh==ssh -machinefile ./machinefile -np $nprocs $exec <$inputfile >$outputfile

#---Extract energy here ---------------------------------------------
\rm -f $outputfile.old;cp $outputfile $outputfile.old
grep Etot $outputfile |tail -1|awk '{print $NF}' >external.ene

#---Extract force here ----------------------------------------------
for ((i=1;i<=$n;i++))
do
echo f.$i.f >>external.ene
done
sed -i 1d $a.FA
j=1
for i in `cat lasp.coord.tmp|awk '{print $NF}'`
do
  f=`sed -n "$j"p $a.FA|awk '{print $2,$3,$4}'`
  sed -i "s/f.$i.f/$f/" external.ene
  let "j=$j+1"
done

#---Extract stress here ---------------------------------------------
grep 'siesta: Stress tensor (total)' siesta.out -A3|sed 1d|awk -v m=-1 '{print $1*m,$2*m,$3*m}' >>external.ene

#---Cleanance -------------------------------------------------------
rm -rf INPUT_TMP.* fdf-*.log
